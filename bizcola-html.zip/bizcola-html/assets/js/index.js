/*
No es tan complicado, solo deben importar el JS con el idioma español y despues le indican al datepicker que usaran ese idioma.
*/

$('#datepicker').datepicker({
  uiLibrary: 'bootstrap4',
  locale: 'es-es',
});